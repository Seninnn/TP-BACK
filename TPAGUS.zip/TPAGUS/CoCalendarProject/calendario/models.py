# calendario/models.py

from django.db import models
from django.contrib.auth.models import User # Usaremos el modelo base de Django para Usuario

# --- Mapeo de Tablas de tu DER ---

# 1. Grupo (Entidad Grupo [cite: 116])
class Grupo(models.Model):
    # id_grupo se crea automáticamente por Django
    titulo = models.CharField(max_length=50, null=False) # varchar NN
    color = models.CharField(max_length=7, default='#000000') # varchar(7) para códigos de color (ej: #FFFFFF)
    
    # id_admin (Relacionado con la tabla Usuario) [cite: 117]
    admin = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='grupos_administrados') # int NN
    
    def _str_(self):
        return self.titulo

# 2. UsuarioGrupo (Relación Muchos a Muchos con atributo 'rol' [cite: 91])
class UsuarioGrupo(models.Model):
    # id_usuario
    usuario = models.ForeignKey(User, on_delete=models.CASCADE) 
    # id_grupo
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE)
    rol = models.CharField(max_length=50, default='Miembro', null=False) # varchar(50) NN

    class Meta:
        # Asegura que un usuario solo pueda estar una vez en un grupo
        unique_together = ('usuario', 'grupo')

# 3. Evento (Entidad Evento [cite: 126])
class Evento(models.Model):
    # id_evento se crea automáticamente
    titulo = models.CharField(max_length=200, null=False) # varchar(200) NN
    descripcion = models.TextField(blank=True, default='') # text
    lugar = models.CharField(max_length=255, blank=True, default='') # varchar(255)
    
    fecha_inicio = models.DateTimeField(null=False) # datetime NN
    fecha_fin = models.DateTimeField(null=False) # datetime NN
    
    estado = models.CharField(max_length=50, default='Activo', null=False) # varchar(50) NN
    
    # id_grupo
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE, null=False) # int NN
    # id_creador
    creador = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='eventos_creados') # int NN
    
    def _str_(self):
        return self.titulo

# 4. BloquearDia (Entidad BloquearDia [cite: 142])
class BloquearDia(models.Model):
    # id_usuario
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, null=False)
    fecha = models.DateField(null=False) # date NN
    motivo = models.CharField(max_length=255, blank=True)