from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import get_user_model
from .models import Grupo, Evento, OpcionEvento, Encuesta, OpcionEncuesta

# Obtener el modelo de usuario de Django
User = get_user_model()


# =======================================================
# 1. Formularios de Autenticación
# =======================================================

class LoginForm(AuthenticationForm):
    """
    Formulario de inicio de sesión basado en la clase de Django.
    Se personaliza para usar 'username' en lugar de 'email' si es necesario, 
    o simplemente para aplicar estilos.
    """
    username = forms.CharField(
        label='Nombre de Usuario',
        widget=forms.TextInput(attrs={'class': 'input', 'placeholder': 'Nombre de Usuario'})
    )
    password = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={'class': 'input', 'placeholder': 'Contraseña'})
    )
    # Nota: AuthenticationForm ya maneja la lógica de validación


class RegistroForm(UserCreationForm):
    """
    Formulario de creación de nuevo usuario.
    Hereda de UserCreationForm para manejar la creación segura de contraseñas.
    """
    class Meta:
        model = User
        fields = ('username', 'email') # Incluye los campos que desees que el usuario complete
        field_classes = {'username': forms.CharField, 'email': forms.EmailField}
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Aplicar estilos a los campos
        for field_name in self.fields:
            self.fields[field_name].widget.attrs.update({'class': 'input'})


# =======================================================
# 2. Formularios de Grupos
# =======================================================

class GrupoForm(forms.ModelForm):
    """
    Formulario para crear y editar el modelo Grupo.
    """
    class Meta:
        model = Grupo
        # Se excluye 'admin' y 'miembros' porque se añaden en la vista
        exclude = ('admin', 'miembros') 
        fields = ['titulo', 'descripcion', 'color', 'tipo']
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'input'}),
            'descripcion': forms.Textarea(attrs={'class': 'textarea', 'rows': 3}),
            'color': forms.TextInput(attrs={'class': 'input', 'type': 'color'}), # Widget de color
            'tipo': forms.Select(attrs={'class': 'select'})
        }


# =======================================================
# 3. Formularios de Eventos
# =======================================================

class EventoForm(forms.ModelForm):
    """
    Formulario para crear y editar el modelo Evento.
    """
    class Meta:
        model = Evento
        # Se excluye 'creador' porque se añade en la vista
        exclude = ('creador',) 
        fields = ['grupo', 'titulo', 'descripcion', 'lugar', 'estado', 'fecha_inicio', 'fecha_fin']
        
        widgets = {
            'grupo': forms.Select(attrs={'class': 'select'}),
            'titulo': forms.TextInput(attrs={'class': 'input'}),
            'descripcion': forms.Textarea(attrs={'class': 'textarea', 'rows': 3}),
            'lugar': forms.TextInput(attrs={'class': 'input'}),
            'estado': forms.Select(attrs={'class': 'select'}),
            # Usamos widgets HTML5 para fecha/hora
            'fecha_inicio': forms.DateTimeInput(attrs={'class': 'input', 'type': 'datetime-local'}),
            'fecha_fin': forms.DateTimeInput(attrs={'class': 'input', 'type': 'datetime-local'}),
        }


class OpcionEventoForm(forms.ModelForm):
    """
    Formulario para que los usuarios propongan nuevas fechas/horas para eventos pendientes.
    """
    class Meta:
        model = OpcionEvento
        # 'evento' se asigna en la vista
        exclude = ('evento',) 
        fields = ['fecha_inicio', 'fecha_fin']
        widgets = {
            'fecha_inicio': forms.DateTimeInput(attrs={'class': 'input', 'type': 'datetime-local'}),
            'fecha_fin': forms.DateTimeInput(attrs={'class': 'input', 'type': 'datetime-local'}),
        }


# =======================================================
# 4. Formularios de Encuestas
# =======================================================

class EncuestaForm(forms.ModelForm):
    """
    Formulario para crear el modelo Encuesta.
    """
    class Meta:
        model = Encuesta
        # 'creador' se asigna en la vista
        exclude = ('creador',) 
        fields = ['grupo', 'titulo', 'descripcion']
        widgets = {
            'grupo': forms.Select(attrs={'class': 'select'}),
            'titulo': forms.TextInput(attrs={'class': 'input'}),
            'descripcion': forms.Textarea(attrs={'class': 'textarea', 'rows': 3}),
        }


class OpcionEncuestaForm(forms.ModelForm):
    """
    Formulario para que los usuarios propongan nuevas opciones para una encuesta.
    """
    class Meta:
        model = OpcionEncuesta
        # 'encuesta' se asigna en la vista
        exclude = ('encuesta',) 
        fields = ['opcion']
        widgets = {
            'opcion': forms.TextInput(attrs={'class': 'input'}),
        }