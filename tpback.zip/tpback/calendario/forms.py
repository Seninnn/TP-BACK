# calendario/forms.py

from django import forms
from .models import (
    Grupo, 
    Evento, 
    OpcionEvento, 
    Encuesta, 
    OpcionEncuesta 
)
from django.forms import inlineformset_factory

# --- GrupoForm ---
class GrupoForm(forms.ModelForm):
    class Meta:
        model = Grupo
        fields = ['titulo', 'color']
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Título del Grupo'}),
            'color': forms.TextInput(attrs={'type': 'color', 'class': 'form-control form-control-color'}),
        }

# --- EventoForm ---
class EventoForm(forms.ModelForm):
    TIPO_OPCIONES = [
        ('fijo', 'Evento de Fecha Fija'),
        ('votacion', 'Evento de Votación'),
    ]
    tipo_evento = forms.ChoiceField(
        choices=TIPO_OPCIONES, 
        initial='fijo', 
        required=True,
        widget=forms.Select(attrs={'class': 'form-select', 'onchange': 'toggleFormSections()'})
    )

    class Meta:
        model = Evento
        fields = ['titulo', 'descripcion', 'grupo', 'lugar', 'fecha_inicio', 'fecha_fin']
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Cena de Navidad'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'grupo': forms.Select(attrs={'class': 'form-select'}),
            'lugar': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Zoom, Casa de Juan'}),
            'fecha_inicio': forms.DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'}),
            'fecha_fin': forms.DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'}),
        }

# --- OpcionEventoForm (Formset para opciones de evento) ---
class OpcionEventoForm(forms.ModelForm):
    class Meta:
        model = OpcionEvento
        fields = ['fecha_inicio', 'fecha_fin']
        widgets = {
            'fecha_inicio': forms.DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'}),
            'fecha_fin': forms.DateTimeInput(attrs={'class': 'form-control', 'type': 'datetime-local'}),
        }

OpcionEventoFormSet = inlineformset_factory(
    Evento, 
    OpcionEvento, 
    form=OpcionEventoForm, 
    extra=1, 
    can_delete=True
)


# --- EncuestaForm (CORREGIDO) ---
class EncuestaForm(forms.ModelForm):
    class Meta:
        model = Encuesta
        # SOLO TITULO Y GRUPO
        fields = ['titulo', 'grupo'] 
        widgets = {
            'titulo': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Título de la Encuesta'}),
            'grupo': forms.Select(attrs={'class': 'form-select'}),
        }


# --- OpcionEncuestaForm (Formset para opciones de encuesta) ---
class OpcionEncuestaForm(forms.ModelForm):
    class Meta:
        model = OpcionEncuesta
        fields = ['opcion']
        widgets = {
            'opcion': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ej: Lunes, Opción A, etc.'}),
        }

OpcionEncuestaFormSet = inlineformset_factory(
    Encuesta, 
    OpcionEncuesta, 
    form=OpcionEncuestaForm, 
    fields=['opcion'],
    extra=2, 
    can_delete=True
)

# --- InvitacionForm (Simple Form) ---
class InvitacionForm(forms.Form):
    """ Formulario simple para buscar usuarios por email o username. """
    email_o_usuario = forms.CharField(
        max_length=150, 
        label="Email o Usuario a Invitar",
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Email o Nombre de Usuario'})
    )