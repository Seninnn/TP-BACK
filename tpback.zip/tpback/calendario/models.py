# calendario/models.py

from django.db import models
from django.contrib.auth.models import User # Modelo de usuario predeterminado de Django
from django.utils import timezone # Uso recomendado por Django para fechas/horas

# ====================================================================
# Modelos de Base (Entidades principales)
# ====================================================================

# [cite_start]Tabla Grupo [cite: 116-119, 182, 198-199]
class Grupo(models.Model):
    titulo = models.CharField(max_length=50) 
    color = models.CharField(max_length=7, default='#000000') 
    # Usa User directamente (es un modelo externo)
    admin = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='grupos_administrados')
    
    def __str__(self):
        return self.titulo

# [cite_start]Tabla Evento [cite: 126, 200]
class Evento(models.Model):
    titulo = models.CharField(max_length=200) 
    descripcion = models.TextField(blank=True, default='') 
    lugar = models.CharField(max_length=255, blank=True, default='')
    
    fecha_inicio = models.DateTimeField(null=True, blank=True) 
    fecha_fin = models.DateTimeField(null=True, blank=True)
    
    estado = models.CharField(max_length=50, default='Activo') 
    
    # Referencia a Grupo (ya está definido arriba)
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE) 
    creador = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='eventos_creados')
    
    def __str__(self):
        return self.titulo

# [cite_start]Tabla BloquearDia [cite: 142, 207]
class BloquearDia(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE) 
    fecha = models.DateField() 
    motivo = models.CharField(max_length=255, blank=True)

# [cite_start]Tabla Notificacion [cite: 147-157, 214]
class Notificacion(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE) 
    tipo = models.CharField(max_length=50) 
    mensaje = models.TextField() 
    fecha_hora = models.DateTimeField(default=timezone.now) 
    leida = models.BooleanField(default=False) 

# ====================================================================
# Modelos de Relación (Manejo de Grupos y Votaciones)
# ====================================================================

# [cite_start]Tabla UsuarioGrupo (Relación Muchos a Muchos con atributo) [cite: 91, 183]
class UsuarioGrupo(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE) 
    # Usamos la clase Grupo directamente, ya que está definida
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE)
    rol = models.CharField(max_length=50, default='Miembro') 

    class Meta:
        # Asegura que un usuario no pueda estar dos veces en el mismo grupo
        unique_together = ('usuario', 'grupo')

# [cite_start]Tabla Encuesta (Contenedor de opciones de votación general) [cite: 101-108, 168-173, 184-189]
class Encuesta(models.Model):
    titulo = models.CharField(max_length=200) 
    fecha_creacion = models.DateTimeField(default=timezone.now) 
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE) 
    creador = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='encuestas_creadas')
    
    def __str__(self):
        return self.titulo

# [cite_start]Tabla OpcionEvento (Opciones de fecha para un evento a definir) [cite: 109-115, 174-181]
class OpcionEvento(models.Model):
    # CORRECCIÓN: Usa string 'Evento' para la referencia (soluciona fields.E300)
    evento = models.ForeignKey('Evento', on_delete=models.CASCADE) 
    fecha_inicio = models.DateTimeField() 
    fecha_fin = models.DateTimeField()

# [cite_start]Tabla OpcionEncuesta (Opciones de votación de una encuesta) [cite: 120-125, 191-197]
class OpcionEncuesta(models.Model):
    # CORRECCIÓN: Usa string 'Encuesta' para la referencia
    encuesta = models.ForeignKey('Encuesta', on_delete=models.CASCADE)
    opcion = models.CharField(max_length=255) 
    
    def __str__(self):
        return f"{self.encuesta.titulo} - {self.opcion}"

# [cite_start]Tabla VotoEvento (Voto de usuario por una OpcionEvento) [cite: 93-100, 159-167]
class VotoEvento(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE) 
    # CORRECCIÓN: Usa string 'OpcionEvento' para la referencia
    opcion_evento = models.ForeignKey('OpcionEvento', on_delete=models.CASCADE) 
    fecha_voto = models.DateTimeField(default=timezone.now) 

# [cite_start]Tabla VotoEncuesta (Voto de usuario por una OpcionEncuesta) [cite: 137-141, 203]
class VotoEncuesta(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE) 
    # CORRECCIÓN: Usa string 'OpcionEncuesta' para la referencia
    opcion_encuesta = models.ForeignKey('OpcionEncuesta', on_delete=models.CASCADE) 
    fecha_voto = models.DateTimeField(default=timezone.now)