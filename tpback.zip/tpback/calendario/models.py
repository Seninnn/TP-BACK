from django.db import models
from django.conf import settings
from django.utils.text import slugify

# Obtiene el modelo de usuario activo (django.contrib.auth.models.User o tu modelo personalizado)
User = settings.AUTH_USER_MODEL 


# =======================================================
# 1. Modelos de Grupos
# =======================================================

class Grupo(models.Model):
    """Representa un grupo al que pertenecen múltiples usuarios."""
    
    TIPO_CHOICES = [
        ('Publico', 'Público'),
        ('Privado', 'Privado'),
    ]

    titulo = models.CharField(max_length=100, unique=True)
    descripcion = models.TextField(blank=True, null=True)
    
    # Campo para almacenar un color (ej. '#FF5733')
    color = models.CharField(max_length=7, default='#007bff') 
    
    tipo = models.CharField(max_length=10, choices=TIPO_CHOICES, default='Privado')
    
    # El administrador del grupo (clave foránea al modelo User)
    admin = models.ForeignKey(User, related_name='grupos_administrados', on_delete=models.CASCADE)
    
    # Los miembros del grupo (relación Many-to-Many al modelo User)
    miembros = models.ManyToManyField(User, related_name='grupos_pertenece', blank=True)
    
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Grupo"
        verbose_name_plural = "Grupos"
    
    def __str__(self):
        return self.titulo
    
    # Se puede añadir lógica para el slug si es necesario
    # slug = models.SlugField(unique=True, blank=True)
    # def save(self, *args, **kwargs):
    #     self.slug = slugify(self.titulo)
    #     super().save(*args, **kwargs)


# =======================================================
# 2. Modelos de Eventos y Opciones de Votación
# =======================================================

class Evento(models.Model):
    """Representa un evento asociado a un grupo."""
    
    ESTADO_CHOICES = [
        ('Definido', 'Definido'),
        ('Pendiente', 'Pendiente (Requiere Votación)'),
    ]

    titulo = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True, null=True)
    lugar = models.CharField(max_length=100, blank=True, null=True)
    
    estado = models.CharField(max_length=20, choices=ESTADO_CHOICES, default='Definido')
    
    # Fechas solo se usan si el estado es 'Definido'
    fecha_inicio = models.DateTimeField(blank=True, null=True)
    fecha_fin = models.DateTimeField(blank=True, null=True)
    
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE, related_name='eventos')
    creador = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='eventos_creados')
    
    fecha_creacion = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Evento"
        verbose_name_plural = "Eventos"
        ordering = ['fecha_inicio']

    def __str__(self):
        return f"{self.titulo} en {self.grupo.titulo}"


class OpcionEvento(models.Model):
    """Opciones de fecha/hora para eventos 'Pendientes'."""

    evento = models.ForeignKey(Evento, on_delete=models.CASCADE, related_name='opciones_horario')
    fecha_inicio = models.DateTimeField()
    fecha_fin = models.DateTimeField()
    
    class Meta:
        verbose_name = "Opción de Horario"
        verbose_name_plural = "Opciones de Horario"
        unique_together = ('evento', 'fecha_inicio', 'fecha_fin')

    def __str__(self):
        return f"Opción para {self.evento.titulo}: {self.fecha_inicio.strftime('%d/%m %H:%M')}"


class VotoOpcionEvento(models.Model):
    """Votos de usuarios a una opción de evento (solo un voto por usuario/evento)."""

    opcion_evento = models.ForeignKey(OpcionEvento, on_delete=models.CASCADE, related_name='voto_evento')
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='votos_evento')
    
    fecha_voto = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Voto de Evento"
        verbose_name_plural = "Votos de Eventos"
        # Restringe a un voto por usuario por evento.
        unique_together = ('opcion_evento', 'usuario')

    def __str__(self):
        return f"Voto de {self.usuario.username} para {self.opcion_evento.evento.titulo}"


# =======================================================
# 3. Modelos de Encuestas y Votación
# =======================================================

class Encuesta(models.Model):
    """Representa una encuesta asociada a un grupo."""

    titulo = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True, null=True)
    
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE, related_name='encuestas')
    creador = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='encuestas_creadas')
    
    fecha_creacion = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Encuesta"
        verbose_name_plural = "Encuestas"

    def __str__(self):
        return f"Encuesta: {self.titulo}"


class OpcionEncuesta(models.Model):
    """Opciones de respuesta para una encuesta."""

    encuesta = models.ForeignKey(Encuesta, on_delete=models.CASCADE, related_name='opciones')
    opcion = models.CharField(max_length=255) # El texto de la opción
    
    class Meta:
        verbose_name = "Opción de Encuesta"
        verbose_name_plural = "Opciones de Encuestas"

    def __str__(self):
        return f"Opción '{self.opcion}' de {self.encuesta.titulo}"


class VotoOpcionEncuesta(models.Model):
    """Votos de usuarios a una opción de encuesta (solo un voto por usuario/encuesta)."""
    
    opcion = models.ForeignKey(OpcionEncuesta, on_delete=models.CASCADE, related_name='voto_encuesta')
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, related_name='votos_encuesta')
    
    # Se añade una referencia a la encuesta para asegurar la unicidad (evita multiples votos en la misma encuesta)
    encuesta = models.ForeignKey(Encuesta, on_delete=models.CASCADE) 
    
    fecha_voto = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        verbose_name = "Voto de Encuesta"
        verbose_name_plural = "Votos de Encuestas"
        # Restringe a un voto por usuario por encuesta.
        unique_together = ('encuesta', 'usuario')

    def __str__(self):
        return f"Voto de {self.usuario.username} en {self.encuesta.titulo}"