# calendario/views.py

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.db import transaction 
from datetime import date
from calendar import Calendar
from django.utils import timezone 

# Importaciones adicionales para la nueva funcionalidad y consultas
from django.db.models import Q, Count 
from django import forms 

# Importar modelos (Asegúrate de que estos nombres coincidan con tus modelos)
from .models import (
    Grupo, 
    Evento, 
    UsuarioGrupo, 
    Encuesta, 
    BloquearDia, 
    OpcionEvento,
    VotoEvento,
    OpcionEncuesta,
    VotoEncuesta
)

# Importar formularios definidos en forms.py
from .forms import (
    GrupoForm, 
    EventoForm, 
    EncuestaForm,  
    OpcionEventoFormSet,
    OpcionEncuestaFormSet, 
    InvitacionForm
)


# ====================================================================
# --- Vistas de Autenticación y Navegación ---
# ====================================================================

def login_view(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            error = 'Usuario o contraseña incorrectos.'
            
    return render(request, 'login.html', {'error': error})


def registro_view(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')

        if password != password2:
            error = 'Las contraseñas no coinciden.'
        elif User.objects.filter(username=username).exists():
            error = 'Ese nombre de usuario ya está registrado.'
        else:
            User.objects.create_user(username, email, password)
            user = authenticate(request, username=username, password=password)
            login(request, user)
            return redirect('dashboard') 

    return render(request, 'registro.html', {'error': error})


@login_required
def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def dashboard_view(request):
    """ Muestra la página principal y notificaciones. """
    notificaciones = [] 
    grupos_ids = UsuarioGrupo.objects.filter(usuario=request.user).values_list('grupo_id', flat=True)
    
    # 1. Buscar eventos de votación pendientes
    eventos_votacion = Evento.objects.filter(
        grupo_id__in=grupos_ids,
        estado='Votacion'
    ).exclude(
        opcionevento__votoevento__usuario=request.user
    ).distinct().select_related('grupo')
    
    for evento in eventos_votacion:
        notificaciones.append({
            'tipo': 'Votación Evento',
            'mensaje': f"Debes votar el evento '{evento.titulo}' en el grupo {evento.grupo.titulo}.",
            'url': redirect('votar_evento', evento_id=evento.id).url
        })
    
    # 2. Buscar encuestas pendientes
    encuestas_pendientes = Encuesta.objects.filter(
        grupo_id__in=grupos_ids
    ).exclude(
        opcionencuesta__votoencuesta__usuario=request.user
    ).distinct().select_related('grupo')

    for encuesta in encuestas_pendientes:
        notificaciones.append({
            'tipo': 'Encuesta Pendiente',
            'mensaje': f"Participa en la encuesta '{encuesta.titulo}' en el grupo {encuesta.grupo.titulo}.",
            'url': redirect('votar_encuesta', encuesta_id=encuesta.id).url 
        })
    
    return render(request, 'dashboard.html', {'notificaciones': notificaciones})


@login_required
def ajustes_view(request):
    """ Muestra la página de ajustes, incluyendo los días que el usuario ha bloqueado. """
    dias_bloqueados = BloquearDia.objects.filter(usuario=request.user).order_by('-fecha')
    
    return render(request, 'ajustes.html', {'dias_bloqueados': dias_bloqueados})


# ====================================================================
# --- Vistas de Grupos ---
# ====================================================================

@login_required
def grupos_view(request):
    """ Muestra todos los grupos a los que pertenece el usuario. """
    grupos_del_usuario = Grupo.objects.filter(
        usuariogrupo__usuario=request.user 
    ).distinct()

    context = {
        'grupos': grupos_del_usuario
    }
    return render(request, 'grupos.html', context)


@login_required
def crear_grupo_view(request):
    """ Maneja la creación de un nuevo grupo. """
    if request.method == 'POST':
        form = GrupoForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                grupo = form.save(commit=False)
                grupo.admin = request.user
                grupo.save()
                
                # Crea la entrada UsuarioGrupo para el administrador
                UsuarioGrupo.objects.create(
                    usuario=request.user, 
                    grupo=grupo, 
                    rol='Admin'
                )
            
            return redirect('grupos') 
    else:
        form = GrupoForm()
    
    return render(request, 'crear_grupo.html', {'form': form})


@login_required
def detalle_grupo_view(request, grupo_id):
    """ Muestra los detalles de un grupo, sus miembros y el formulario de invitación. """
    
    grupo = get_object_or_404(Grupo, pk=grupo_id)
    
    # 1. Verificar que el usuario pertenece al grupo
    if not UsuarioGrupo.objects.filter(usuario=request.user, grupo=grupo).exists():
        return redirect('grupos') 
    
    # Obtener los miembros del grupo
    miembros = UsuarioGrupo.objects.filter(grupo=grupo).select_related('usuario').order_by('rol')
    
    # Determinar si el usuario actual es administrador
    es_admin = miembros.filter(usuario=request.user, rol='Admin').exists()
    
    invitacion_form = InvitacionForm()
    
    context = {
        'grupo': grupo,
        'miembros': miembros,
        'es_admin': es_admin,
        'invitacion_form': invitacion_form,
    }
    return render(request, 'detalle_grupo.html', context)


@login_required
def invitar_miembro_view(request, grupo_id):
    """ Busca un usuario por email/username y lo añade al grupo (solo para Admin). """
    grupo = get_object_or_404(Grupo, pk=grupo_id)
    
    # Verificar que el usuario actual es administrador
    if not UsuarioGrupo.objects.filter(usuario=request.user, grupo=grupo, rol='Admin').exists():
        return redirect('detalle_grupo', grupo_id=grupo_id) 
    
    if request.method == 'POST':
        form = InvitacionForm(request.POST)
        if form.is_valid():
            busqueda = form.cleaned_data['email_o_usuario']
            
            try:
                # Intentar encontrar al usuario por username O email
                usuario_a_invitar = User.objects.get(
                    Q(username=busqueda) | Q(email=busqueda)
                )
                
                # Prevenir auto-invitación o si ya es miembro
                if UsuarioGrupo.objects.filter(usuario=usuario_a_invitar, grupo=grupo).exists():
                    pass 
                else:
                    # Añadir como miembro
                    UsuarioGrupo.objects.create(
                        usuario=usuario_a_invitar, 
                        grupo=grupo, 
                        rol='Miembro'
                    )
                
            except User.DoesNotExist:
                pass 
            
    return redirect('detalle_grupo', grupo_id=grupo_id)

# ====================================================================
# --- Vistas de Eventos y Calendario ---
# ====================================================================

@login_required
def crear_evento_view(request):
    """ Maneja la creación de un nuevo evento (fijo o de votación) usando Formset. """
    
    grupos_del_usuario = Grupo.objects.filter(usuariogrupo__usuario=request.user).distinct()
    
    if request.method == 'POST':
        tipo_evento = request.POST.get('tipo_evento')
        form = EventoForm(request.POST)
        formset = OpcionEventoFormSet(request.POST) 
    else:
        tipo_evento = request.GET.get('tipo_evento', 'fijo')
        form = EventoForm(initial={'tipo_evento': tipo_evento})
        formset = OpcionEventoFormSet(queryset=OpcionEvento.objects.none()) 

    form.fields['grupo'].queryset = grupos_del_usuario
    
    if request.method == 'POST':
        if form.is_valid():
            with transaction.atomic():
                evento = form.save(commit=False)
                evento.creador = request.user
                
                if tipo_evento == 'fijo':
                    # 1. Evento de Fecha Fija
                    evento.estado = 'Definido' 
                    evento.save()
                    
                elif tipo_evento == 'votacion':
                    # 2. Evento de Votación
                    if formset.is_valid():
                        evento.fecha_inicio = None
                        evento.fecha_fin = None
                        evento.lugar = "" 
                        
                        evento.estado = 'Votacion'
                        evento.save() 
                        
                        opciones = formset.save(commit=False)
                        for opcion in opciones:
                            if opcion.fecha_inicio and opcion.fecha_fin: 
                                opcion.evento = evento
                                opcion.save()
                    else:
                        context = {'form': form, 'formset': formset}
                        form.fields['grupo'].queryset = grupos_del_usuario
                        return render(request, 'crear_evento.html', context)

                return redirect('calendario') 

    context = {
        'form': form,
        'formset': formset,
    }
    return render(request, 'crear_evento.html', context)


@login_required
def detalle_evento_view(request, evento_id):
    """ Muestra los detalles de un evento (fijo o votación). """
    evento = get_object_or_404(Evento, pk=evento_id)
    
    if not UsuarioGrupo.objects.filter(usuario=request.user, grupo=evento.grupo).exists():
        return redirect('calendario') 
    
    if evento.estado == 'Votacion':
        return redirect('votar_evento', evento_id=evento_id)
        
    context = {
        'evento': evento
    }
    return render(request, 'detalle_evento.html', context)


@login_required
def votar_evento_view(request, evento_id):
    """ Permite al usuario ver las opciones de un evento de votación y emitir su voto. """
    evento = get_object_or_404(Evento, pk=evento_id, estado='Votacion')
    
    if not UsuarioGrupo.objects.filter(usuario=request.user, grupo=evento.grupo).exists():
        return redirect('calendario') 

    opciones = OpcionEvento.objects.filter(evento=evento).annotate(
        votos_count=Count('votoevento')
    ).order_by('-votos_count', 'fecha_inicio') 
    
    # NOTA: Usamos 'opcion_evento' para la consulta de VotoEvento
    voto_actual = VotoEvento.objects.filter(
        usuario=request.user, 
        opcion_evento__evento=evento
    ).first()
    
    if request.method == 'POST':
        opcion_id = request.POST.get('opcion_id')
        opcion_seleccionada = get_object_or_404(OpcionEvento, pk=opcion_id, evento=evento)
        
        if voto_actual:
            voto_actual.delete()
            
        VotoEvento.objects.create(usuario=request.user, opcion_evento=opcion_seleccionada)
        
        return redirect('votar_evento', evento_id=evento_id)
    
    es_admin_grupo = UsuarioGrupo.objects.filter(
        usuario=request.user,
        grupo=evento.grupo,
        rol='Admin'
    ).exists()
    
    context = {
        'evento': evento,
        'opciones': opciones,
        'voto_actual_id': voto_actual.opcion_evento_id if voto_actual else None,
        'es_admin_grupo': es_admin_grupo, 
    }
    return render(request, 'votar_evento.html', context)


@login_required
def finalizar_votacion_evento_view(request, evento_id):
    """
    Finaliza un evento de votación, calcula la opción ganadora y fija el evento.
    Solo accesible para el creador del evento o un Admin del grupo.
    """
    evento = get_object_or_404(Evento, pk=evento_id, estado='Votacion')

    es_admin_grupo = UsuarioGrupo.objects.filter(
        usuario=request.user, 
        grupo=evento.grupo, 
        rol='Admin'
    ).exists()
    
    if request.user != evento.creador and not es_admin_grupo:
        return redirect('votar_evento', evento_id=evento_id) 

    opciones = OpcionEvento.objects.filter(evento=evento).annotate(
        votos_count=Count('votoevento')
    ).order_by('-votos_count', 'fecha_inicio')
    
    if not opciones:
        return redirect('votar_evento', evento_id=evento_id)
        
    opcion_ganadora = opciones.first()
    
    with transaction.atomic():
        evento.fecha_inicio = opcion_ganadora.fecha_inicio
        evento.fecha_fin = opcion_ganadora.fecha_fin
        evento.lugar = opcion_ganadora.lugar
        evento.estado = 'Definido' 
        evento.save()
        
        # Eliminar las opciones de votación (y los votos asociados)
        OpcionEvento.objects.filter(evento=evento).delete()

    return redirect('detalle_evento', evento_id=evento.id)


@login_required
def calendario_view(request):
    """ Genera el contexto para mostrar el calendario mensual. """
    hoy = date.today()
    
    ano_actual = int(request.GET.get('ano', hoy.year))
    mes_actual_num = int(request.GET.get('mes', hoy.month))
    
    grupo_ids = UsuarioGrupo.objects.filter(usuario=request.user).values_list('grupo_id', flat=True)
    
    eventos_del_mes = Evento.objects.filter(
        grupo_id__in=grupo_ids,
        fecha_inicio__year=ano_actual,
        fecha_inicio__month=mes_actual_num,
    ).exclude(estado='Votacion').select_related('grupo').order_by('fecha_inicio')
    
    eventos_por_dia = {}
    for evento in eventos_del_mes:
        dia = evento.fecha_inicio.day
        eventos_por_dia.setdefault(dia, []).append(evento)
        
    cal = Calendar(firstweekday=6) 
    matriz_mes = cal.monthdays2calendar(ano_actual, mes_actual_num)
    
    calendario_data = []
    for semana in matriz_mes:
        semana_data = []
        for dia_num, weekday in semana:
            dia_data = {
                'numero': dia_num if dia_num != 0 else None,
                'es_este_mes': dia_num != 0,
                'es_hoy': (dia_num == hoy.day and mes_actual_num == hoy.month and ano_actual == hoy.year) if dia_num != 0 else False,
                'eventos': eventos_por_dia.get(dia_num, []) if dia_num != 0 else [],
                'weekday': weekday
            }
            semana_data.append(dia_data)
        calendario_data.append(semana_data)
    
    mes_prev = mes_actual_num - 1 if mes_actual_num > 1 else 12
    ano_prev = ano_actual if mes_actual_num > 1 else ano_actual - 1
    mes_next = mes_actual_num + 1 if mes_actual_num < 12 else 1
    ano_next = ano_actual if mes_actual_num < 12 else ano_actual + 1

    context = {
        'mes_actual': date(ano_actual, mes_actual_num, 1).strftime('%B').capitalize(), 
        'ano_actual': ano_actual,
        'calendario_html': calendario_data,
        'mes_prev': mes_prev,
        'ano_prev': ano_prev,
        'mes_next': mes_next,
        'ano_next': ano_next,
    }
    
    return render(request, 'calendario.html', context)


# ====================================================================
# --- Vistas de Encuestas y Bloqueo de Días ---
# ====================================================================

@login_required
def encuestas_view(request):
    """ Lista las encuestas disponibles para los grupos del usuario. """
    grupo_ids = UsuarioGrupo.objects.filter(usuario=request.user).values_list('grupo_id', flat=True)
    
    encuestas_activas = Encuesta.objects.filter(grupo_id__in=grupo_ids).order_by('-fecha_creacion')
    
    context = {
        'encuestas': encuestas_activas
    }
    return render(request, 'encuestas.html', context)


@login_required
def crear_encuesta_view(request):
    """ Maneja la creación de una nueva encuesta usando Formset. """
    grupos_del_usuario = Grupo.objects.filter(usuariogrupo__usuario=request.user)
    
    if request.method == 'POST':
        form = EncuestaForm(request.POST)
        form.fields['grupo'].queryset = grupos_del_usuario 
        formset = OpcionEncuestaFormSet(request.POST)

        if form.is_valid() and formset.is_valid():
            with transaction.atomic():
                encuesta = form.save(commit=False)
                encuesta.creador = request.user
                encuesta.save()
                
                opciones = formset.save(commit=False)
                for opcion in opciones:
                    if opcion.opcion.strip(): 
                        opcion.encuesta = encuesta
                        opcion.save()
            
            return redirect('encuestas')
            
    else:
        form = EncuestaForm()
        form.fields['grupo'].queryset = grupos_del_usuario 
        formset = OpcionEncuestaFormSet(queryset=OpcionEncuesta.objects.none())
        
    context = {
        'form': form, 
        'formset': formset
    }
    return render(request, 'crear_encuesta.html', context)


@login_required
def votar_encuesta_view(request, encuesta_id):
    """ Permite al usuario votar en una encuesta. """
    encuesta = get_object_or_404(Encuesta, pk=encuesta_id)
    
    if not UsuarioGrupo.objects.filter(usuario=request.user, grupo=encuesta.grupo).exists():
        return redirect('encuestas') 

    opciones = OpcionEncuesta.objects.filter(encuesta=encuesta).annotate(
        votos_count=Count('votoencuesta')
    ).order_by('-votos_count', 'id')
    
    # CORRECCIÓN DEFINITIVA: Usa 'opcion_encuesta' para la consulta
    voto_actual = VotoEncuesta.objects.filter(
        usuario=request.user, 
        opcion_encuesta__encuesta=encuesta
    ).first()
    
    if request.method == 'POST':
        opcion_id = request.POST.get('opcion_id')
        opcion_seleccionada = get_object_or_404(OpcionEncuesta, pk=opcion_id, encuesta=encuesta)
        
        if voto_actual:
            voto_actual.delete() 
            
        # Al crear, también usamos 'opcion_encuesta'
        VotoEncuesta.objects.create(usuario=request.user, opcion_encuesta=opcion_seleccionada)
        
        return redirect('votar_encuesta', encuesta_id=encuesta_id)
    
    context = {
        'encuesta': encuesta,
        'opciones': opciones,
        # Al pasar el ID, usamos 'opcion_encuesta_id'
        'voto_actual_id': voto_actual.opcion_encuesta_id if voto_actual else None,
    }
    return render(request, 'votar_encuesta.html', context)


@login_required
def bloquear_dia_view(request):
    """ Permite al usuario bloquear un día en su calendario. """
    if request.method == 'POST':
        fecha_str = request.POST.get('fecha_bloqueo') 
        motivo = request.POST.get('motivo')
        
        try:
            fecha_bloqueada = date.fromisoformat(fecha_str)
            
            BloquearDia.objects.update_or_create(
                usuario=request.user,
                fecha=fecha_bloqueada,
                defaults={'motivo': motivo}
            )
            return redirect('ajustes') 
        except (ValueError, TypeError):
            return redirect('ajustes') 
    
    return redirect('ajustes')