from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout, get_user_model 
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count

# Importamos solo los modelos que existen. Quitamos 'Usuario'.
from .models import Grupo, Evento, Encuesta, OpcionEvento, OpcionEncuesta, VotoOpcionEvento
from .forms import LoginForm, RegistroForm, GrupoForm, EventoForm, OpcionEventoForm, EncuestaForm, OpcionEncuestaForm

# Obtener el modelo de usuario activo de Django
User = get_user_model() 

# Otros módulos de Python necesarios
import calendar
from datetime import date, datetime, timedelta

# =======================================================
# 1. Rutas de Autenticación
# =======================================================

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('dashboard')
            else:
                messages.error(request, 'Nombre de usuario o contraseña incorrectos.')
        else:
            messages.error(request, 'Error en el formulario de inicio de sesión.')
    else:
        form = LoginForm()
        
    return render(request, 'login.html', {'form': form})

def registro_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Opcional: Iniciar sesión automáticamente después del registro
            login(request, user) 
            messages.success(request, 'Registro exitoso. ¡Bienvenido!')
            return redirect('dashboard')
        else:
            # Pasa los errores del formulario para mostrarlos
            return render(request, 'registro.html', {'form': form})
    else:
        form = RegistroForm()
        
    return render(request, 'registro.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    messages.info(request, 'Sesión cerrada exitosamente.')
    return redirect('login')

# =======================================================
# 2. Rutas de Navegación Principal
# =======================================================

@login_required
def dashboard_view(request):
    # CORRECCIÓN DE LÓGICA: Acceso a grupos por la relación 'miembros'
    grupos_del_usuario = Grupo.objects.filter(miembros=request.user)
    
    # Obtener eventos pendientes o próximos
    eventos_proximos = Evento.objects.filter(
        grupo__in=grupos_del_usuario,
        fecha_inicio__gte=datetime.now()
    ).order_by('fecha_inicio')[:5]

    context = {
        'grupos': grupos_del_usuario,
        'eventos_proximos': eventos_proximos
    }
    return render(request, 'dashboard.html', context)

@login_required
def ajustes_view(request):
    return render(request, 'ajustes.html')

# =======================================================
# 3. Rutas de Grupos
# =======================================================

@login_required
def grupos_view(request):
    # CORRECCIÓN DE LÓGICA: Obtener solo los grupos a los que pertenece el usuario
    mis_grupos = Grupo.objects.filter(miembros=request.user)
    
    context = {
        'grupos': mis_grupos
    }
    return render(request, 'grupos.html', context)

@login_required
def crear_grupo_view(request):
    if request.method == 'POST':
        form = GrupoForm(request.POST)
        if form.is_valid():
            grupo = form.save(commit=False)
            grupo.admin = request.user
            grupo.save()
            
            # Asegurar que el creador sea miembro del grupo
            grupo.miembros.add(request.user) 
            messages.success(request, f'Grupo "{grupo.titulo}" creado exitosamente.')
            return redirect('grupos')
    else:
        form = GrupoForm()
    
    return render(request, 'crear_grupo.html', {'form': form})

# =======================================================
# 4. Rutas de Eventos y Calendario
# =======================================================

def generar_calendario(ano, mes, user):
    """Genera la estructura de datos del calendario con eventos."""
    cal = calendar.Calendar(firstweekday=6) # 6 = Domingo
    cal_mes = cal.monthdatescalendar(ano, mes)
    
    # CORRECCIÓN DE LÓGICA: Obtener los IDs de los grupos del usuario
    grupo_ids = Grupo.objects.filter(miembros=user).values_list('id', flat=True)
    
    eventos_mes = Evento.objects.filter(
        grupo_id__in=grupo_ids,
        fecha_inicio__year=ano,
        fecha_inicio__month=mes
    ).select_related('grupo')

    calendario_html = []
    hoy = date.today()

    for semana in cal_mes:
        semana_data = []
        for dia in semana:
            dia_data = {
                'numero': dia.day if dia.month == mes else None,
                'es_este_mes': dia.month == mes,
                'es_hoy': dia == hoy,
                'eventos': [e for e in eventos_mes if e.fecha_inicio.date() == dia]
            }
            semana_data.append(dia_data)
        calendario_html.append(semana_data)
        
    return calendario_html

@login_required
def calendario_view(request, ano=None, mes=None):
    now = datetime.now()
    ano_actual = ano if ano else now.year
    mes_actual = mes if mes else now.month
    
    calendario_data = generar_calendario(ano_actual, mes_actual, request.user)
    
    context = {
        'calendario_html': calendario_data,
        'mes_actual': datetime(ano_actual, mes_actual, 1).strftime('%B'),
        'ano_actual': ano_actual
    }
    return render(request, 'calendario.html', context)

@login_required
def crear_evento_view(request):
    # CORRECCIÓN: Filtrar grupos a los que el usuario pertenece
    grupos_del_usuario = Grupo.objects.filter(miembros=request.user) 
    
    if request.method == 'POST':
        form = EventoForm(request.POST)
        form.fields['grupo'].queryset = grupos_del_usuario
        
        if form.is_valid():
            evento = form.save(commit=False)
            evento.creador = request.user
            evento.save()
            messages.success(request, f'Evento "{evento.titulo}" creado exitosamente.')
            
            if evento.estado == 'Pendiente':
                 return redirect('detalle_evento', evento_id=evento.id) 
            
            return redirect('calendario')
    else:
        form = EventoForm()
        form.fields['grupo'].queryset = grupos_del_usuario
        
    return render(request, 'crear_evento.html', {'form': form})

@login_required
def detalle_evento_view(request, evento_id):
    evento = get_object_or_404(Evento, id=evento_id)
    opciones = OpcionEvento.objects.filter(evento=evento).annotate(votos=Count('votoopcionevento'))
    voto_realizado = None
    
    # 1. Chequear si el usuario ya votó
    try:
        voto_realizado = VotoOpcionEvento.objects.get(usuario=request.user, opcion_evento__evento=evento).opcion_evento_id
    except VotoOpcionEvento.DoesNotExist:
        pass

    # 2. Manejo de formularios POST (Votar u Proponer Opción)
    if request.method == 'POST':
        # --- Votar Opción ---
        if 'votar_opcion' in request.POST:
            opcion_id = request.POST.get('votar_opcion')
            opcion = get_object_or_404(OpcionEvento, id=opcion_id, evento=evento)
            
            # Eliminar voto anterior si existe
            VotoOpcionEvento.objects.filter(usuario=request.user, opcion_evento__evento=evento).delete()
            
            # Registrar nuevo voto
            VotoOpcionEvento.objects.create(usuario=request.user, opcion_evento=opcion)
            messages.success(request, 'Voto registrado.')
            return redirect('detalle_evento', evento_id=evento.id)

        # --- Proponer Opción ---
        elif 'proponer_opcion' in request.POST:
            opcion_form = OpcionEventoForm(request.POST)
            if opcion_form.is_valid():
                nueva_opcion = opcion_form.save(commit=False)
                nueva_opcion.evento = evento
                nueva_opcion.save()
                messages.success(request, 'Nueva opción propuesta.')
                return redirect('detalle_evento', evento_id=evento.id)
            else:
                 messages.error(request, 'Error al proponer la opción.')
                 opcion_form_final = opcion_form
        
    # 3. Preparar contexto
    es_pendiente = evento.estado == 'Pendiente'
    
    if es_pendiente and 'opcion_form_final' not in locals():
        opcion_form_final = OpcionEventoForm()
    
    context = {
        'evento': evento,
        'opciones': opciones,
        'es_pendiente': es_pendiente,
        'voto_realizado': voto_realizado,
        'opcion_form': opcion_form_final if es_pendiente else None,
    }
    return render(request, 'detalle_evento.html', context)


# =======================================================
# 5. Rutas de Encuestas y Votación
# =======================================================

@login_required
def encuestas_view(request):
    # CORRECCIÓN DE LÓGICA: Obtener IDs de grupos donde el usuario es miembro
    grupo_ids = Grupo.objects.filter(miembros=request.user).values_list('id', flat=True)
    
    # Obtener encuestas de esos grupos
    encuestas_activas = Encuesta.objects.filter(grupo_id__in=grupo_ids).order_by('-fecha_creacion')
    
    context = {
        'encuestas': encuestas_activas
    }
    return render(request, 'encuestas.html', context)


@login_required
def crear_encuesta_view(request):
    # CORRECCIÓN DE LÓGICA: Obtener grupos donde el usuario es miembro
    grupos_del_usuario = Grupo.objects.filter(miembros=request.user)
    
    if request.method == 'POST':
        form = EncuestaForm(request.POST)
        form.fields['grupo'].queryset = grupos_del_usuario
        
        if form.is_valid():
            encuesta = form.save(commit=False)
            encuesta.creador = request.user
            encuesta.save()
            messages.success(request, f'Encuesta "{encuesta.titulo}" creada. Ahora añade opciones.')
            return redirect('detalle_encuesta', encuesta_id=encuesta.id)
        else:
            messages.error(request, 'Error al crear la encuesta.')
    else:
        form = EncuestaForm()
        form.fields['grupo'].queryset = grupos_del_usuario
        
    return render(request, 'crear_encuesta.html', {'form': form})

@login_required
def detalle_encuesta_view(request, encuesta_id):
    encuesta = get_object_or_404(Encuesta, id=encuesta_id)
    opciones = OpcionEncuesta.objects.filter(encuesta=encuesta).annotate(votos=Count('votoopcionencuesta'))
    
    # Determinar si el usuario ya votó
    voto_del_usuario = None
    try:
        # Nota: Asumimos que VotoOpcionEncuesta tiene un campo 'encuesta' para esta consulta
        voto_del_usuario = encuesta.votoopcionencuesta_set.get(usuario=request.user).opcion_id
    except:
        pass

    if request.method == 'POST':
        if 'votar_opcion' in request.POST:
            opcion_id = request.POST.get('votar_opcion')
            opcion = get_object_or_404(OpcionEncuesta, id=opcion_id, encuesta=encuesta)
            
            # Borrar voto anterior
            encuesta.votoopcionencuesta_set.filter(usuario=request.user).delete()
            
            # Registrar nuevo voto
            opcion.votoopcionencuesta_set.create(usuario=request.user, encuesta=encuesta)
            messages.success(request, 'Voto registrado.')
            return redirect('detalle_encuesta', encuesta_id=encuesta.id)
        
        elif 'proponer_opcion' in request.POST:
            opcion_form = OpcionEncuestaForm(request.POST)
            if opcion_form.is_valid():
                nueva_opcion = opcion_form.save(commit=False)
                nueva_opcion.encuesta = encuesta
                nueva_opcion.save()
                messages.success(request, 'Opción añadida a la encuesta.')
                return redirect('detalle_encuesta', encuesta_id=encuesta.id)
            else:
                 messages.error(request, 'Error al proponer la opción.')
                 opcion_form_final = opcion_form
    
    if 'opcion_form_final' not in locals():
        opcion_form_final = OpcionEncuestaForm()
        
    context = {
        'encuesta': encuesta,
        'opciones': opciones,
        'voto_del_usuario': voto_del_usuario,
        'opcion_form': opcion_form_final
    }
    return render(request, 'detalle_encuesta.html', context)

# =======================================================
# 6. Rutas de Utilidad
# =======================================================

@login_required
def bloquear_dia_view(request):
    return render(request, 'bloquear_dia.html')