# calendario/urls.py

from django.urls import path
from . import views

urlpatterns = [
    # --- Rutas de Autenticación ---
    path('', views.login_view, name='login'),
    path('registro/', views.registro_view, name='registro'),
    path('logout/', views.logout_view, name='logout'),

    # --- Rutas de Navegación Principal ---
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('ajustes/', views.ajustes_view, name='ajustes'),
    
    # --- Rutas de Grupos ---
    path('grupos/', views.grupos_view, name='grupos'),
    path('grupos/crear/', views.crear_grupo_view, name='crear_grupo'),
    
    # --- Rutas de Eventos y Calendario ---
    path('calendario/', views.calendario_view, name='calendario'),
    path('evento/crear/', views.crear_evento_view, name='crear_evento'),
    path('evento/<int:evento_id>/', views.detalle_evento_view, name='detalle_evento'),
    
    # --- Rutas de Encuestas y Votación ---
    path('encuestas/', views.encuestas_view, name='encuestas'),
    path('encuestas/crear/', views.crear_encuesta_view, name='crear_encuesta'),
    path('encuestas/<int:encuesta_id>/', views.detalle_encuesta_view, name='detalle_encuesta'),
    
    # --- Rutas de Utilidad ---
    path('bloquear-dia/', views.bloquear_dia_view, name='bloquear_dia'), 
]