# calendario/urls.py

from django.urls import path
from . import views 

urlpatterns = [
    # --- Rutas de Autenticación y Navegación ---
    path('', views.login_view, name='login'), # Ruta principal /
    path('registro/', views.registro_view, name='registro'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('ajustes/', views.ajustes_view, name='ajustes'),
    path('ajustes/bloquear/', views.bloquear_dia_view, name='bloquear_dia'),


    # --- Rutas de Grupos ---
    path('grupos/', views.grupos_view, name='grupos'),
    path('grupos/crear/', views.crear_grupo_view, name='crear_grupo'),
    path('grupos/<int:grupo_id>/', views.detalle_grupo_view, name='detalle_grupo'),
    path('grupos/<int:grupo_id>/invitar/', views.invitar_miembro_view, name='invitar_miembro'),

    
    # --- Rutas de Calendario y Eventos ---
    path('calendario/', views.calendario_view, name='calendario'),
    path('evento/crear/', views.crear_evento_view, name='crear_evento'),
    path('evento/<int:evento_id>/detalle/', views.detalle_evento_view, name='detalle_evento'),
    path('evento/<int:evento_id>/votar/', views.votar_evento_view, name='votar_evento'),
    path('evento/<int:evento_id>/finalizar_votacion/', views.finalizar_votacion_evento_view, name='finalizar_votacion_evento'),
    
    # --- Rutas de Encuestas ---
    path('encuestas/', views.encuestas_view, name='encuestas'),
    path('encuestas/crear/', views.crear_encuesta_view, name='crear_encuesta'),
    path('encuestas/<int:encuesta_id>/votar/', views.votar_encuesta_view, name='votar_encuesta'),
]