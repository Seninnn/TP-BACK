# CoCalendarProject/urls.py (O el nombre que tenga tu proyecto principal)

from django.contrib import admin
from django.urls import path, include 
from django.conf import settings 
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # CRÍTICO: Incluir todas las rutas de la aplicación calendario bajo la raíz ('')
    path('', include('calendario.urls')), 
]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)