# CoCalendarProject/urls.py (O el nombre que tenga tu proyecto principal)

from django.contrib import admin
from django.urls import path, include 

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # CRÍTICO: Incluir todas las rutas de la aplicación calendario bajo la raíz ('')
    path('', include('calendario.urls')), 
]